﻿namespace test2
{
    class DdImpl : Dd
    {
    }
}