﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test3
{
    public class test
    {
        public int I { get; set; }
        public string S { get; set; }
        public test()
        {
            Console.WriteLine(  "ASdas");
        }

     
    }
    interface IInterface
    {
             
    }

    abstract class  MyClass
    {
         
    }

         
    
}
